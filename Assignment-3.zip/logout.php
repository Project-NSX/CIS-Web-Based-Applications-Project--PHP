<?php
// TODO: Demonstrate
session_start();
unset($_SESSION['userID']);
unset($_SESSION['userEmail']);
unset($_SESSION['fName']);
unset($_SESSION['lName']);
$succ_msg = 0;
$_SESSION['readyForCheckout'] = false;
header('Location: index.php?succ_msg=' . $succ_msg);
exit;
