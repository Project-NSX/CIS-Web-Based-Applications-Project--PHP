<?php

// Set to 0 when code goes live
define("DEBUG", 1);

?>