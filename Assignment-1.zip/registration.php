<?php
$pageTitle = "Register";
require('includes/application_top.php');
require('includes/site_header.php');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title">Register</h2>
            </div>
            <div class="panel-body">
                <form method="post" id="registration_form" class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-12 control-label" for="username">Username: </label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" name="username" id="username" placeholder="Username" maxlength="100" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-12 control-label" for="username">Password: </label>
                        <div class="col-sm-12">
                            <input type="password" class="form-control" name="password" id="password" placeholder="Password" maxlength="50" required />
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <input type="submit" class="btn btn-primary btn-block" name="action" value="Register" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
require('includes/site_footer.php');
?>