<?php
$pageTitle = "Product Details";
require('includes/application_top.php');
require('includes/site_header.php');
?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading, text-center">
                <h2 class="panel-title">Premium Ladder + Free Bloke</h2>
            </div>
            <div class="text-center">
                <div class="panel-body" style="padding: 20px">
                    <div class="row">
                        <div class="col-md-3">
                            <img class="img" src="/images/products/ladderandman.jpg" alt="Premium Ladder And Free Bloke">
                        </div>
                        <div class="col-md-4">
                            <h4 class="text-left">
                                Description:
                            </h4>
                            <p class="text-left">
                                Premium ladder made of high quality stainless steel. Suitable for all jobs around the home such as cleaning windows.<br />
                                Strong but lightweight, as is the bloke that comes with the ladder.<br />
                                The bloke provided can clean up to 300 windows an hour, provided sufficient amounts of coffee are supplied.
                            </p>
                        </div>
                        <div class="col-md-5, text-left">
                            <h5 class="text-left">
                                Price: £300
                            </h5>
                            <form method="post" action="basket.php" id="add-to-basket" class="form-horizontal,text-left">
                                <div class="form-group">
                                    <label class="col-sm-12 control-label" for="quantity">Quantity: </label>
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control" name="quantity" id="quantity" value="1" required />
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <input type="submit" class="btn btn-primary btn-block" name="action" value="Add To Basket" required />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
require('includes/site_footer.php');
?>