<?php
$pageTitle = "Home";
require('includes/application_top.php');
require('includes/site_header.php');
?>


<div class="row main-content">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title">Products</h2>
            </div>
            <div class="panel-body">
                <div class="row products">
                    <div class="col-md-3 product">
                        <h3>Chamoizon Basics Ladder</h3>
                        <img class="img-thumb" src="images/products/ladder.jpg" alt="Chamoizon Basics Ladder" />
                        <p>
                            £50
                        </p>
                        <div class="row btn_row">
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="product-details.php">Product Details</a>
                            </div>
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="basket.php">Add to Basket</a>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-3 product">
                        <h3>Premium Ladder + Free Bloke</h3>
                        <img class="img-thumb" src="images/products/ladderandman.jpg" alt="Premium Ladder + Free Bloke" />
                        <p>
                            £300
                        </p>
                        <div class="row btn_row">
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="product-details.php">Product Details</a>
                            </div>
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="basket.php">Add to Basket</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 product">
                        <h3>Chamoizon Chamoise Leather</h3>
                        <img class="img-thumb" src="images/products/chamois.jpg" alt="Chamoizon Chamoise Leather" />
                        <p>
                            £15
                        </p>
                        <div class="row btn_row">
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="product-details.php">Product Details</a>
                            </div>
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="basket.php">Add to Basket</a>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-3 product">
                        <h3>Cheapo Telescopic Ladder</h3>
                        <img class="img-thumb" src="images/products/teleladder.png" alt="Cheapo Telescopic Ladder" />
                        <p>
                            £15
                        </p>
                        <div class="row btn_row">
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="product-details.php">Product Details</a>
                            </div>
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="basket.php">Add to Basket</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 product">
                        <h3>Chamoizon Basics Squeegee</h3>
                        <img class="img-thumb" src="images/products/squeegee.jpg" alt="Chamoizon Basics Squeegee" />
                        <p>
                            £15
                        </p>
                        <div class="row btn_row">
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="product-details.php">Product Details</a>
                            </div>
                            <div class="col-md-6 button">
                                <a class="btn btn-secondary btn block" href="basket.php">Add to Basket</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
require('includes/site_footer.php');

?>