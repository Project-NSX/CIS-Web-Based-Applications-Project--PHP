<?php
$pageTitle = "Basket";
require('includes/application_top.php');
require('includes/site_header.php');
?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title">Basket</h2>
                <hr />
            </div>
            <div class="panel-body">
                <div class="panel panel-default">
                    <div class="panel-body, text-center" style="padding: 20px">
                        <div class="row">
                            <div class="col-md-3">
                                <img class="img-thumb" src="/images/products/ladderandman.jpg" alt="Premium Ladder And Free Bloke">
                            </div>
                            <div class="col-md-6">
                                <h4>
                                    Premium Ladder + Free Bloke
                                </h4>
                                <p>
                                    Premium ladder made of high quality stainless steel.
                                </p>
                            </div>
                            <div class="col-md-3">
                                <form method="post" action="basket.php" id="add-to-basket" class="form-horizontal, text-left">
                                    <div class="form-group">
                                        <label class="col-sm-12 control-label" for="quantity">Quantity: </label>
                                        <div class="col-sm-12">
                                            <input type="number" class="form-control" name="quantity" id="quantity" value="1" required />
                                            <b>Item Price:</b> £300 <br />
                                            <b>Total:</b> £300 <br />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <input type="submit" class="btn btn-primary btn-block" name="action" value="Update Quantity" />
                                        <input type="submit" class="btn btn-secondary btn-block" name="action" value="Delete From Basket" />
                                    </div>
                                </form>
                            </div>
                        </div>
                        <hr />
                        <div class="row">
                            <div class="col-md-3">
                                <img class="img-thumb" src="/images/products/squeegee.jpg" alt="Premium Ladder And Free Bloke">
                            </div>
                            <div class="col-md-6">
                                <h4>
                                    Chamoizon Basics Squeegee
                                </h4>
                                <p>
                                    High quaity low price squeegee
                                </p>
                            </div>
                            <div class="col-md-3">

                                <form method="post" action="basket.php" id="add-to-basket" class="form-horizontal, text-left">
                                    <div class="form-group">
                                        <label class="col-sm-12 control-label" for="quantity">Quantity: </label>
                                        <div class="col-sm-12">
                                            <input type="number" class="form-control" name="quantity" id="quantity" value="1" required />
                                            <b>Item Price:</b> £15 <br />
                                            <b>Total:</b> £15 <br />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <input type="submit" class="btn btn-primary btn-block" name="action" value="Update Quantity" />
                                        <input type="submit" class="btn btn-secondary btn-block" name="action" value="Delete From Basket" />
                                    </div>
                                </form>
                            </div>
                        </div>
                        <hr />
                        <div class="row">
                            <div class="col-md-3">
                                <img class="img-thumb" src="/images/products/chamois.jpg" alt="Chamoizon Chamoise Leather">
                            </div>
                            <div class="col-md-6">
                                <h4>
                                    Chamoizon Chamoise Leather
                                </h4>
                                <p>
                                    Chamizon's high quality and durable chamoise leather
                                </p>
                            </div>
                            <div class="col-md-3">

                                <form method="post" action="basket.php" id="add-to-basket" class="form-horizontal, text-left">
                                    <div class="form-group">
                                        <label class="col-sm-12 control-label" for="quantity">Quantity: </label>
                                        <div class="col-sm-12">
                                            <input type="number" class="form-control" name="quantity" id="quantity" value="1" required />
                                            <b>Item Price:</b> £15 <br />
                                            <b>Total:</b> £15 <br />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <input type="submit" class="btn btn-primary btn-block" name="action" value="Update Quantity" />
                                        <input type="submit" class="btn btn-secondary btn-block" name="action" value="Delete From Basket" />
                                    </div>
                                </form>
                            </div>
                        </div>
                        <hr />
                        <div class="row">
                            <div class="col-md-12">
                                <form method="post" action="checkout.php" id="add-to-basket" class="form horizontal">
                                    <div class="form-group">
                                        <div class="col-sm-12" style="align-items: center">
                                            <input type="submit" class="btn btn-primary btn-block" name="action" value="Checkout" />
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('includes/site_footer.php');
?>