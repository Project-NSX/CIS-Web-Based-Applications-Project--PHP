<?php
$pageTitle = "Login";
require('includes/application_top.php');
require('includes/site_header.php');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title">Login</h2>
            </div>
            <div class="panel-body">


                <?php
                require('includes/functions/login-function.php');

                $success = false;
                $error_message = false;

                $defaultUN = "";
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $usernameEntered = trim($_POST["username"]);
                    $passwordEntered = $_POST["password"];

                    $success = loginFunction($usernameEntered, $passwordEntered);
                    $defaultUN = htmlspecialchars($usernameEntered);
                    $success_message = "Success! Welcome " . htmlspecialchars($usernameEntered);
                    // Insert error message decision here
                    if (!$success) {
                        $error_message = "Please enter a valid username and password";
                    }
                }


                if ($success) {
                ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="alert alert-success">
                                <p><?= $success_message ?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                } else {
                    if ($error_message) {
                    ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="alert alert-danger">
                                    <p><?php echo $error_message ?></p>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                    <form method="post" action="login.php" id="login_form" class="form horizontal">
                        <div class="form-group">
                            <label class="col-sm-12 control-label" for="username">Username: </label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="username" id="username" placeholder="Username" maxlength="100" value="<?= htmlspecialchars($defaultUN) ?>" required />
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-12 control-label" for="username">Password: </label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" name="password" id="password" placeholder="Password" maxlength="50" required />
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <input type="submit" class="btn btn-primary btn-block" name="action" value="Login" />
                        </div>
                    </form>

                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
<?php
require('includes/site_footer.php');
?>