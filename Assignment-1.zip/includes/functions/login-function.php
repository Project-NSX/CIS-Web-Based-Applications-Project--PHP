<?php
function loginFunction($usernameEntered, $passwordEntered)
{
    $success = false;
    if($usernameEntered == USERNAME && $passwordEntered == PASSWORD)
    {
            $success = true;
    }
    return $success;
}
?>