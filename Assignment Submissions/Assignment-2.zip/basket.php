<?php
$pageTitle = "Basket";
require('includes/application_top.php');
require('includes/site_header.php');

//$productID = isset($_GET['id']) ? $_GET['id'] : '';
$productID = $_POST['productID'];
$quantity = $_POST['quantity'];

?>
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title">Basket</h2>
                <hr />
            </div>
            <div class="panel-body">
                <div class="panel panel-default">
                    <div class="panel-body, text-center" style="padding: 20px">
                        <?php
                            if($productID)
                            {
                                populateBasket($productID, $quantity);
                            }
                        ?>
                        <!--Bottom of Basket-->
                        <div class="row">
                            <div class="col-md-12">
                                <form method="post" action="checkout.php" id="add-to-basket" class="form horizontal">
                                    <div class="form-group">
                                        <div class="col-sm-12" style="align-items: center">
                                            <input type="submit" class="btn btn-primary btn-block" name="action" value="Checkout" />
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('includes/site_footer.php');
?>