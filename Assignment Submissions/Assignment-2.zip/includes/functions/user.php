<?php

// Returns bool of true or false for login usage
function login($emailEntered, $passwordEntered)
{
    global $db;
    $success = false;

    $sql = "SELECT customerID FROM customer where email='". mysqli_real_escape_string($db, $emailEntered) ."' AND password = '". mysqli_real_escape_string($db, $passwordEntered) ."'";
    $result = mysqli_query($db, $sql);
    $user_details = mysqli_fetch_assoc($result);

    if($user_details['customerID'])
    {
        $success = true;
    }
    return $success;
}

function emailValid($email)
{
    global $db;
    $sql = "SELECT email, customerID FROM customer WHERE email = '" . $email . "'";
    $result = mysqli_query($db, $sql);
    $user_details = mysqli_fetch_assoc($result);

    if($user_details['email'] != $email)
    {
        $emailValid = true;
    }
    else
    {
        $emailValid = false;
    }
    return $emailValid;
}

function addCustomer($email, $password, $fName, $lName, $address)
{
    global $db;
    $sql = "INSERT INTO customer (email, password, fName, lName, address) VALUES ('". mysqli_real_escape_string($db, $email) ."', '" . mysqli_real_escape_string($db, $password) . "', '" . mysqli_real_escape_string($db, $fName) . "', '" . mysqli_real_escape_string($db, $lName) ."' , '" . mysqli_real_escape_string($db, $address) ."')";
    $result = mysqli_query($db, $sql);
    return $result;
}

?>