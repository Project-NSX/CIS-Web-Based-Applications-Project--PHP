<?php

// Set to 0 when code goes live
define("DEBUG", 1);

$key = "bPeShVmYq3t6w9z$";

?>